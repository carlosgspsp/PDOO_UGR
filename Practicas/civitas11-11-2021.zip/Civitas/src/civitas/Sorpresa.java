/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

import java.util.ArrayList;

/**
 *
 * @author carlo
 */
public class Sorpresa {

    String texto;
    int valor;
    TipoSorpresa tipo;
    MazoSorpresas mazo;

    Sorpresa(TipoSorpresa tipo, String texto, int valor) {
        this.texto = texto;
        this.valor = valor;
        this.tipo = tipo;
    }

    private void informe(int actual, ArrayList<Jugador> todos) {
        Diario.getInstance().ocurreEvento("Se esta aplicando una sorpresa al jugador " + todos.get(actual).getNombre());
    }

    void aplicarAJugador(int actual, ArrayList<Jugador> todos) {
        switch (tipo) {
            case PAGARCOBRAR:
                aplicarAJugador_pagarCobrar(actual, todos);
                break;
            case PORCASAHOTEL:
                aplicarAJugador_porCasaHotel(actual, todos);
                break;

        }

    }

    void aplicarAJugador_pagarCobrar(int actual, ArrayList<Jugador> todos) {
        informe(actual, todos);
        todos.get(actual).modificarSaldo(valor);
    }

    void aplicarAJugador_porCasaHotel(int actual, ArrayList<Jugador> todos) {
        informe(actual, todos);
        Jugador aux = todos.get(actual);
        aux.modificarSaldo(valor * aux.cantidadCasasHoteles());
    }

    public String toString() {
        return texto;
    }

   

}
