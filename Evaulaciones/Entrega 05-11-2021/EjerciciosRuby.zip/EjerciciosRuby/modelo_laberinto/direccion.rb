# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module Modelo_laberinto
module Direccion
    NORTE=0
    SUR=1
    ESTE=2
    OESTE=3
end

Lista_direcciones=Array["NORTE", "SUR", "ESTE", "OESTE"]

end