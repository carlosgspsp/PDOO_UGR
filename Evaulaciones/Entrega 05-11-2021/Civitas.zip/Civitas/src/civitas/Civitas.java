/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

import java.util.ArrayList;

/**
 *
 * @author carlo
 */
public class Civitas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /*
        int contadorJugador1 = 0;
        int contadorJugador2 = 0;
        int contadorJugador3 = 0;
        int contadorJugador4 = 0;

        for (int i = 0; i < 100; i++) {
            switch (Dado.getInstance().quienEmpieza(4)) {
                case 0:
                    ++contadorJugador1;
                    break;
                case 1:
                    ++contadorJugador2;
                    break;
                case 2:
                    ++contadorJugador3;
                    break;
                case 3:
                    ++contadorJugador4;
                    break;
            }

        }
        System.out.println("\n\nCOMPROBACION DE QUE JUGADOR EMPIEZA");
        System.out.println("\nJugador 1: " + contadorJugador1 + "\nJugador 2: " + contadorJugador2 + "\nJugador 3: " + contadorJugador3 + "\nJugador 4: " + contadorJugador4);

        System.out.println("\n\nTIRADAS CON DEBUG DESACTIVADO");
        for (int i = 0; i < 6; i++) {
            Dado.getInstance().tirar();
            System.out.println("\n" + Dado.getInstance().getUltimoResultado());
        }

        System.out.println("\n\nTIRADAS CON DEBUG ACTIVADO");
        Dado.getInstance().setDebug(true);
        for (int i = 0; i < 6; i++) {
            Dado.getInstance().tirar();
            System.out.println("\n" + Dado.getInstance().getUltimoResultado());
        }

        System.out.println("\n\nPRUEBAS CON TABLERO");

        Tablero tablero = new Tablero(5);

        tablero.añadeCasilla(new Casilla(TipoCasilla.CALLE, "Camino de Ronda", 500, 150, 200));
        tablero.añadeCasilla(new Casilla(TipoCasilla.CALLE, "Doctor Fleming", 250, 50, 100));
        tablero.añadeCasilla(new Casilla(TipoCasilla.CALLE, "Avenida Madrid", 400, 100, 150));
        tablero.añadeCasilla(new Casilla(TipoCasilla.CALLE, "Pedro Antonio", 1000, 500, 350));

        for (int i = 0; i < 5; i++) {
            System.out.println("\n\n\n" + tablero.getCasilla(i).toString());
        }

        float cara = 0, barata = 0, suma = 0;
        Casilla casillaCara = new Casilla(null, "", 0, 0, 0);
        Casilla casillaBarata = new Casilla(null, "", 0, 0, 0);
        for (int i = 1; i < 5; i++) {

            Casilla casilla = tablero.getCasilla(i);
            float precio = casilla.getPrecioCompra();

            if (i == 1) {
                barata = precio;
                cara = barata;
                casillaCara = casilla;
                casillaBarata = casilla;
            }
            if (precio < barata) {
                barata = precio;
                casillaBarata = casilla;
            }
            if (precio > cara) {
                cara = precio;
                casillaCara = casilla;
            }
            suma += precio;
        }

        float media = suma / 4;

        System.out.println("\n\nLa calle mas cara es: " + casillaCara.toString());
        System.out.println("\n\nLa calle mas barata es: " + casillaBarata.toString());
        System.out.println("\n\nEl precio medio de las calles es: " + media);

        if (Diario.getInstance().eventosPendientes()) {
            for (int i = 0; i < Diario.getInstance().getEventos().size(); i++) {
                //System.out.println(Diario.getInstance().getEventos().get(i));
                System.out.println(Diario.getInstance().leerEvento());
            }
        }

        int posicion = 0;
        Dado.getInstance().setDebug(false);
        System.out.println("\n\nTIRADAS CON DEBUG DESACTIVADO Y CALCULO DE POSICION EN TABLERO");
        for (int i = 0; i < 6; i++) {
            Dado.getInstance().tirar();
            int resultado = Dado.getInstance().getUltimoResultado();
            System.out.println("\nResultado: " + resultado);
            posicion = tablero.nuevaPosicion(posicion, resultado);
            System.out.println("Nueva posicion: " + posicion);
        }

        posicion = 0;
        Dado.getInstance().setDebug(true);
        System.out.println("\n\nTIRADAS CON DEBUG ACTIVADO Y CALCULO DE POSICION EN TABLERO");
        Dado.getInstance().setDebug(true);
        for (int i = 0; i < 6; i++) {
            Dado.getInstance().tirar();
            int resultado = Dado.getInstance().getUltimoResultado();
            System.out.println("\nResultado:" + resultado);
            posicion = tablero.nuevaPosicion(posicion, resultado);
            System.out.println("Nueva posicion: " + posicion);
        }
        */
        
        
       ArrayList<String> jugadores = new ArrayList<>();
       jugadores.add("Jose Manu");
       jugadores.add("Carlos");
       jugadores.add("Argelion");
       jugadores.add("Jorge");
       
       CivitasJuego juego = new CivitasJuego(jugadores);
       
       Jugador actual = juego.getJugadorActual();
       Tablero tablero = juego.getTablero();
       
       System.out.println(actual.toString());
       actual.paga(500);
       System.out.println(actual.toString());
       actual.recibe(500);
       System.out.println(actual.toString());
       
       actual.puedeComprarCasilla();
       actual.moverACasilla(3);
      
        System.out.println(actual.toString());
       
       System.out.println(tablero.nuevaPosicion(actual.getCasillaActual(), 12));
       actual.moverACasilla(tablero.nuevaPosicion(actual.getCasillaActual(), 12));
      Casilla casilla = tablero.getCasilla(tablero.nuevaPosicion(actual.getCasillaActual(), 12));
      casilla.construirCasa();
      System.out.println(casilla.toString());
    }

}
