




module Controlador_laberinto
  module Operacion
    ENTRAR=0
    INTENTAR_AVANZAR=1
    TERMINAR=2

  end

  Lista_operaciones=Array["ENTRAR","INTENTAR_AVANZAR","TERMINAR"]

end