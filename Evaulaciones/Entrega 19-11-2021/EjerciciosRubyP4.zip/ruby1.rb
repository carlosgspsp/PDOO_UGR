class Casilla
  def initialize(nombre)
    @nombre = nombre
  end

  def recibe_jugador
    puts ( "Soy #{@nombre} y estoy andando")
    result = true

  end

end

class CasillaCalle < Casilla
  def initialize(nombre)
    super
    @num_casas = '0'
  end
end


casilla_calle = CasillaCalle.new("pepe")
casilla = Casilla.new("Juan")

casilla.recibe_jugador
casilla_calle.recibe_jugador