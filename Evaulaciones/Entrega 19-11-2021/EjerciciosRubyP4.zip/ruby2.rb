class Casilla
  def initialize(nombre)
    @nombre = nombre
  end

  def recibe_jugador
    puts ( "He recibido un jugador")
    result = true

  end

end

class CasillaCalle < Casilla
  def initialize(nombre)
    super
    @num_casas = '0'
  end

  def recibe_jugador
    puts ( "Soy una casilla calle y he recibido a un jugador")
    result = true

  end

end


casilla_calle = CasillaCalle.new("pepe")
casilla = Casilla.new("Juan")

casilla.recibe_jugador
casilla_calle.recibe_jugador